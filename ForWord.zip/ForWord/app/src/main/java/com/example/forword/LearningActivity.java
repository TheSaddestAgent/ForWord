package com.example.forword;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;

public class LearningActivity extends AppCompatActivity {
    ImageView iv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learning);
        iv = findViewById(R.id.imageView);
        Bitmap meme1_bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.meme1);
        iv.setImageBitmap(meme1_bitmap);
    }
}